const nomlish = require("nomlish");
exports.handler = (event, context, callback) => {

    let text;
    const reqParams = event.body.split(/&/);
    for (const elem of reqParams) {
        let keyValue = elem.split(/=/);
        if (keyValue.length == 2) {
            if (keyValue[0] == "text") {
                text = keyValue[1];
            }
        }
    }
    //console.log("TEXT:"+text);

    text = decodeURIComponent(text);
    text = text.replace("+", " ");
    let level;
    const args = text.split(/ /);
    if (args.length == 2) {
        level = Number(args[0]);
        text = args[1];
    }
    if (level == 0) {
        level = 1;
    }else if (level == 1) {
        level = 4;
    }else {
        level = 2;
    }
    text = text.replace(/\+/g," ");

    //console.log("ARG1:"+level);
    //console.log("ARG2:"+text);

    nomlish.translate(text, level)
        .then(function(nomlishText) {
            let res = "";
            if (nomlishText == "") {
                res = "文章が短すぎるか、長すぎて厨ニ病変換できないよ！";
	    }else {
                res = nomlishText + "\n(訳: " + text + ")";
            }
	    callback(null, res);
        })
};

